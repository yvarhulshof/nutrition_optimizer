from flask import Flask, render_template, request, jsonify
import json
import os

from optimization.ilp_solver import optimize_nutrition

app = Flask(__name__)

# Load foods data at startup
DATA_DIR = os.path.join(os.path.dirname(__file__), "data")
FOODS_FILE = os.path.join(DATA_DIR, "foods.json")

with open(FOODS_FILE, 'r') as f:
    foods_data = json.load(f)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/optimize', methods=['POST'])
def optimize():
    # Extract JSON from the request
    constraints = request.get_json()

    # Call the solver
    solution = optimize_nutrition(constraints, foods_data)

    return jsonify(solution)


if __name__ == '__main__':
    # For local development only; not recommended for production
    app.run(debug=True)
