document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('optimizationForm');
    form.addEventListener('submit', async (e) => {
        e.preventDefault();

        const formData = {
            min_calories: document.getElementById('min_calories').value,
            max_calories: document.getElementById('max_calories').value,
            min_protein: document.getElementById('min_protein').value,
        };

        // Send a POST request to /optimize
        const response = await fetch('/optimize', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(formData),
        });

        const result = await response.json();
        document.getElementById('result').innerText = JSON.stringify(result, null, 2);
    });
});
