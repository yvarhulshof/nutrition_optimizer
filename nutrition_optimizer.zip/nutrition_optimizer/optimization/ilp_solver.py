import pulp

def optimize_nutrition(constraints, foods_data):
    """
    Example ILP that:
    - Minimizes total cost
    - Meets min/max calories if provided
    - Meets minimum protein if provided
    """

    # Create the problem
    problem = pulp.LpProblem("Nutrition_Optimization", pulp.LpMinimize)

    # Define decision variables:
    food_items = list(foods_data.keys())
    x = pulp.LpVariable.dicts('quantity', food_items, lowBound=0, cat=pulp.LpInteger)

    # Objective: minimize total cost
    problem += pulp.lpSum([foods_data[f]['cost'] * x[f] for f in food_items]), "Total_Cost"

    # min_calories constraint
    if 'min_calories' in constraints and constraints['min_calories']:
        min_cal = float(constraints['min_calories'])
        problem += pulp.lpSum([foods_data[f]['calories'] * x[f] for f in food_items]) >= min_cal, "MinCalories"

    # max_calories constraint
    if 'max_calories' in constraints and constraints['max_calories']:
        max_cal = float(constraints['max_calories'])
        problem += pulp.lpSum([foods_data[f]['calories'] * x[f] for f in food_items]) <= max_cal, "MaxCalories"

    # min_protein constraint
    if 'min_protein' in constraints and constraints['min_protein']:
        min_prot = float(constraints['min_protein'])
        problem += pulp.lpSum([foods_data[f]['protein'] * x[f] for f in food_items]) >= min_prot, "MinProtein"

    # Solve the problem
    problem.solve(pulp.PULP_CBC_CMD(msg=0))

    # Prepare the result
    status = pulp.LpStatus[problem.status]
    solution = {
        "status": status,
        "objective_value": pulp.value(problem.objective) if status == 'Optimal' else None,
        "quantities": {}
    }

    if status == 'Optimal':
        # Extract chosen quantities
        for f in food_items:
            qty = x[f].varValue
            if qty > 0:
                solution["quantities"][f] = int(qty)

    return solution
